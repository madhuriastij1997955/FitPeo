def Call():
    variables_for_test_1 = 100
    variables_for_test_2 = [1, 10, 100]
    variables_for_test_3 = {10: 10, 100: 100, 1000: 1000}
    variables_for_test_4 = {(1, 10, 100): (10000, 100000, 100000)}

    all_vars_set = True  # Break here


if __name__ == '__main__':
    Call()
    print('TEST SUCEEDED!')